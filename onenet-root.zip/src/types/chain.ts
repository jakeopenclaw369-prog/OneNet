// Chain types for frontend

export interface User {
  id: string
  name: string
  username: string
  avatar?: string
  bio?: string
  verified: boolean
  x?: number // D3 positioning
  y?: number // D3 positioning
}

export interface Connection {
  id: string
  fromUserId: string
  toUserId: string
  type: ConnectionType
  strength: number // 1-10
  context: string
  source?: User // D3 link source
  target?: User // D3 link target
}

export type ConnectionType = 
  | 'friend' 
  | 'follow' 
  | 'acquaintance' 
  | 'community' 
  | 'event' 
  | 'colleague'
  | 'family'

export interface ChainPath {
  startUserId: string
  endUserId: string
  path: Connection[]
  totalDegrees: number
  strongestConnection: number
  totalStrength: number
  contexts: string[]
}

export interface ChainVisualizationProps {
  users: User[]
  connections: Connection[]
  selectedPath?: ChainPath
  onUserClick?: (user: User) => void
  onUserHover?: (user: User | null) => void
  width?: number
  height?: number
  className?: string
}