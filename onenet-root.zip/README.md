# OneNet Chain MVP - Frontend

🚀 **Live Demo:** [onenetapp.com](https://onenetapp.com)

## Revolutionary Connection Mapping

Chain shows **how** people are connected instead of random "People You May Know."

### Demo Features:
- Interactive D3.js network visualization
- Real-time connection path calculation  
- Relationship strength indicators (1-10 scale)
- Context-rich connections ("College friends → Tech colleagues")
- Mobile-responsive design

### Try the Demo:
1. Click **David Kim** to see: Jake → Alex → David (2 degrees)
2. Click **Mike Johnson** to see: Jake → Maria → Mike (2 degrees)
3. Drag users to explore the network
4. Notice connection strength (line thickness)

## Quick Start

```bash
npm install
npm run dev
```

Visit http://localhost:3000

## Deploy to Vercel

This is a Next.js app optimized for Vercel deployment.

---

**OneNet: Connection mapping that transforms social discovery** ⚡