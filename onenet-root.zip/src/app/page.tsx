'use client'

import { useState, useEffect } from 'react'
import ChainInterface from '@/components/ChainInterface'
import { User, Connection, ChainPath } from '@/types/chain'

// Sample data from our working demo
const sampleUsers: User[] = [
  {
    id: 'jake',
    name: 'Jake Goralnik',
    username: 'jake',
    bio: 'Building the future of social media with OneNet',
    verified: true
  },
  {
    id: 'alex',
    name: 'Alex Chen',
    username: 'alexchen',
    bio: 'Software engineer at Meta',
    verified: false
  },
  {
    id: 'maria',
    name: 'Maria Rodriguez',
    username: 'maria_r',
    bio: 'Miami entrepreneur & startup founder',
    verified: true
  },
  {
    id: 'david',
    name: 'David Kim',
    username: 'davidkim',
    bio: 'VC at Andreessen Horowitz',
    verified: true
  },
  {
    id: 'sarah',
    name: 'Sarah Wilson',
    username: 'sarahw',
    bio: 'Designer & creator',
    verified: false
  },
  {
    id: 'mike',
    name: 'Mike Johnson',
    username: 'mikej',
    bio: 'Miami nightlife promoter',
    verified: false
  },
  {
    id: 'emma',
    name: 'Emma Torres',
    username: 'emmatorres',
    bio: 'UX Designer at Spotify',
    verified: false
  },
  {
    id: 'carlos',
    name: 'Carlos Mendez',
    username: 'carlosm',
    bio: 'Crypto trader & investor',
    verified: true
  }
]

const sampleConnections: Connection[] = [
  // Jake's direct connections
  {
    id: 'conn_1',
    fromUserId: 'jake',
    toUserId: 'alex',
    type: 'friend',
    strength: 8,
    context: 'College friends - University of Miami'
  },
  {
    id: 'conn_2',
    fromUserId: 'jake',
    toUserId: 'maria',
    type: 'colleague',
    strength: 7,
    context: 'Met at Miami Tech Meetup'
  },
  
  // Alex's connections
  {
    id: 'conn_3',
    fromUserId: 'alex',
    toUserId: 'david',
    type: 'colleague',
    strength: 6,
    context: 'Both work in tech, mutual LinkedIn connections'
  },
  {
    id: 'conn_4',
    fromUserId: 'alex',
    toUserId: 'sarah',
    type: 'friend',
    strength: 9,
    context: 'Dating - met on Hinge last year'
  },
  {
    id: 'conn_5',
    fromUserId: 'alex',
    toUserId: 'emma',
    type: 'colleague',
    strength: 7,
    context: 'Both work at tech companies, met at conference'
  },
  
  // Maria's connections
  {
    id: 'conn_6',
    fromUserId: 'maria',
    toUserId: 'mike',
    type: 'acquaintance',
    strength: 5,
    context: 'Miami nightlife scene - mutual friends'
  },
  {
    id: 'conn_7',
    fromUserId: 'maria',
    toUserId: 'david',
    type: 'colleague',
    strength: 8,
    context: 'David invested in Maria\'s startup'
  },
  {
    id: 'conn_8',
    fromUserId: 'maria',
    toUserId: 'carlos',
    type: 'friend',
    strength: 6,
    context: 'Miami crypto community'
  },
  
  // Additional connections to create interesting chains
  {
    id: 'conn_9',
    fromUserId: 'sarah',
    toUserId: 'mike',
    type: 'acquaintance',
    strength: 4,
    context: 'Both attend Miami art events'
  },
  {
    id: 'conn_10',
    fromUserId: 'emma',
    toUserId: 'sarah',
    type: 'colleague',
    strength: 7,
    context: 'Both designers in tech'
  },
  {
    id: 'conn_11',
    fromUserId: 'david',
    toUserId: 'carlos',
    type: 'colleague',
    strength: 5,
    context: 'VC and crypto investor connections'
  },
  {
    id: 'conn_12',
    fromUserId: 'carlos',
    toUserId: 'mike',
    type: 'acquaintance',
    strength: 4,
    context: 'Miami social scene'
  }
]

// Chain calculation engine (simplified for demo)
class ChainEngine {
  private connections = new Map<string, Connection[]>()
  private users = new Map<string, User>()

  constructor(users: User[], connections: Connection[]) {
    users.forEach(user => {
      this.users.set(user.id, user)
      this.connections.set(user.id, [])
    })

    connections.forEach(connection => {
      const fromConnections = this.connections.get(connection.fromUserId) || []
      const toConnections = this.connections.get(connection.toUserId) || []
      
      fromConnections.push(connection)
      
      const reverseConnection: Connection = {
        ...connection,
        id: `${connection.id}_reverse`,
        fromUserId: connection.toUserId,
        toUserId: connection.fromUserId
      }
      toConnections.push(reverseConnection)
      
      this.connections.set(connection.fromUserId, fromConnections)
      this.connections.set(connection.toUserId, toConnections)
    })
  }

  findChainPath(startUserId: string, endUserId: string, maxDegrees: number = 6): ChainPath | null {
    if (startUserId === endUserId) return null
    
    const distances = new Map<string, number>()
    const previous = new Map<string, { userId: string, connection: Connection }>()
    const unvisited = new Set<string>()
    
    for (const userId of this.users.keys()) {
      distances.set(userId, userId === startUserId ? 0 : Infinity)
      unvisited.add(userId)
    }
    
    while (unvisited.size > 0) {
      let currentUserId: string | null = null
      let minDistance = Infinity
      
      for (const userId of unvisited) {
        const distance = distances.get(userId)!
        if (distance < minDistance) {
          minDistance = distance
          currentUserId = userId
        }
      }
      
      if (!currentUserId || minDistance === Infinity) break
      if (minDistance > maxDegrees) break
      
      unvisited.delete(currentUserId)
      
      if (currentUserId === endUserId) {
        return this.reconstructPath(startUserId, endUserId, previous)
      }
      
      const userConnections = this.connections.get(currentUserId) || []
      
      for (const connection of userConnections) {
        if (!unvisited.has(connection.toUserId)) continue
        
        const newDistance = minDistance + 1
        const currentDistance = distances.get(connection.toUserId)!
        
        if (newDistance < currentDistance) {
          distances.set(connection.toUserId, newDistance)
          previous.set(connection.toUserId, {
            userId: currentUserId,
            connection
          })
        }
      }
    }
    
    return null
  }

  private reconstructPath(startUserId: string, endUserId: string, previous: Map<string, { userId: string, connection: Connection }>): ChainPath {
    const path: Connection[] = []
    const contexts: string[] = []
    let totalStrength = 0
    let strongestConnection = 0
    
    let currentUserId = endUserId
    
    while (currentUserId !== startUserId) {
      const prev = previous.get(currentUserId)
      if (!prev) break
      
      path.unshift(prev.connection)
      contexts.unshift(prev.connection.context)
      totalStrength += prev.connection.strength
      strongestConnection = Math.max(strongestConnection, prev.connection.strength)
      
      currentUserId = prev.userId
    }
    
    return {
      startUserId,
      endUserId,
      path,
      totalDegrees: path.length,
      strongestConnection,
      totalStrength,
      contexts: [...new Set(contexts)]
    }
  }
}

export default function HomePage() {
  const [chainEngine] = useState(() => new ChainEngine(sampleUsers, sampleConnections))
  const currentUser = sampleUsers[0] // Jake is the current user

  const handleFindChain = async (startUserId: string, endUserId: string): Promise<ChainPath | null> => {
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 500))
    return chainEngine.findChainPath(startUserId, endUserId)
  }

  return (
    <main className="min-h-screen bg-gray-50">
      <div className="max-w-6xl mx-auto px-4 py-8">
        {/* OneNet branding */}
        <div className="text-center mb-8">
          <h1 className="text-5xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent mb-2">
            OneNet
          </h1>
          <p className="text-xl text-gray-600 mb-1">Chain MVP - Live Demo</p>
          <p className="text-gray-500 mb-3">
            Revolutionary connection mapping that shows <em>how</em> you know people
          </p>
          <div className="inline-flex items-center px-3 py-1 rounded-full bg-green-100 text-green-800 text-sm font-medium">
            🚀 Live at onenetapp.com
          </div>
        </div>

        <ChainInterface
          currentUser={currentUser}
          users={sampleUsers}
          connections={sampleConnections}
          onFindChain={handleFindChain}
        />

        {/* Demo info */}
        <div className="mt-12 p-6 bg-gradient-to-r from-blue-50 to-purple-50 rounded-lg border">
          <h3 className="font-semibold text-lg mb-3">🚀 OneNet Chain Demo</h3>
          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <h4 className="font-medium mb-2">What makes this different:</h4>
              <ul className="text-sm space-y-1 text-gray-700">
                <li>• <strong>Context-rich connections:</strong> See HOW you know people</li>
                <li>• <strong>Strength indicators:</strong> Visual connection strength (1-10)</li>
                <li>• <strong>Multi-path exploration:</strong> Multiple ways to reach someone</li>
                <li>• <strong>Real-time visualization:</strong> Interactive network exploration</li>
              </ul>
            </div>
            <div>
              <h4 className="font-medium mb-2">Try these interactions:</h4>
              <ul className="text-sm space-y-1 text-gray-700">
                <li>• Click on <strong>David Kim</strong> (VC) to see path via Alex or Maria</li>
                <li>• Click on <strong>Mike Johnson</strong> to see Miami nightlife connections</li>
                <li>• Drag users around to explore the network visually</li>
                <li>• Notice verification badges and connection colors</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </main>
  )
}