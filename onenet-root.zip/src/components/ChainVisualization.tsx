'use client'

import { useEffect, useRef, useState } from 'react'
import * as d3 from 'd3'
import { User, Connection, ChainPath, ChainVisualizationProps } from '@/types/chain'

export default function ChainVisualization({
  users,
  connections,
  selectedPath,
  onUserClick,
  onUserHover,
  width = 800,
  height = 600,
  className = ''
}: ChainVisualizationProps) {
  const svgRef = useRef<SVGSVGElement>(null)
  const [hoveredUser, setHoveredUser] = useState<User | null>(null)

  useEffect(() => {
    if (!svgRef.current || !users.length) return

    const svg = d3.select(svgRef.current)
    svg.selectAll("*").remove()

    // Prepare connections for D3 (convert fromUserId/toUserId to source/target)
    const d3Links = connections.map(conn => ({
      ...conn,
      source: conn.fromUserId,
      target: conn.toUserId
    }))

    // Create force simulation
    const simulation = d3.forceSimulation(users)
      .force("link", d3.forceLink(d3Links)
        .id((d: any) => d.id)
        .distance(d => 150 - (d as any).strength * 10) // Stronger connections = closer
      )
      .force("charge", d3.forceManyBody().strength(-300))
      .force("center", d3.forceCenter(width / 2, height / 2))
      .force("collision", d3.forceCollide().radius(40))

    // Create groups for layering
    const linkGroup = svg.append("g").attr("class", "links")
    const nodeGroup = svg.append("g").attr("class", "nodes")

    // Create links (connections)
    const links = linkGroup
      .selectAll("line")
      .data(d3Links)
      .join("line")
      .attr("class", "chain-link")
      .style("stroke", d => {
        if (selectedPath) {
          const isInPath = selectedPath.path.some(p => p.id === d.id)
          return isInPath ? "#3B82F6" : "#E5E7EB"
        }
        return getConnectionColor(d.type)
      })
      .style("stroke-width", d => {
        if (selectedPath) {
          const isInPath = selectedPath.path.some(p => p.id === d.id)
          return isInPath ? Math.max(3, d.strength) : 2
        }
        return Math.max(2, d.strength * 0.8)
      })
      .style("opacity", d => {
        if (selectedPath) {
          const isInPath = selectedPath.path.some(p => p.id === d.id)
          return isInPath ? 1 : 0.3
        }
        return 0.7
      })

    // Create nodes (users)
    const nodes = nodeGroup
      .selectAll("g")
      .data(users)
      .join("g")
      .attr("class", "chain-node")
      .style("cursor", "pointer")
      .call(d3.drag<any, any>()
        .on("start", dragstarted)
        .on("drag", dragged)  
        .on("end", dragended)
      )
      .on("click", (event, d) => {
        event.stopPropagation()
        onUserClick?.(d)
      })
      .on("mouseenter", (event, d) => {
        setHoveredUser(d)
        onUserHover?.(d)
      })
      .on("mouseleave", () => {
        setHoveredUser(null)
        onUserHover?.(null)
      })

    // Add user circles
    nodes.append("circle")
      .attr("r", d => {
        if (selectedPath && (d.id === selectedPath.startUserId || d.id === selectedPath.endUserId)) {
          return 25 // Highlight start/end users
        }
        if (selectedPath) {
          const isInPath = selectedPath.path.some(p => p.fromUserId === d.id || p.toUserId === d.id)
          return isInPath ? 22 : 18
        }
        return 20
      })
      .style("fill", d => {
        if (selectedPath && d.id === selectedPath.startUserId) return "#10B981" // Green for start
        if (selectedPath && d.id === selectedPath.endUserId) return "#EF4444" // Red for end
        if (selectedPath) {
          const isInPath = selectedPath.path.some(p => p.fromUserId === d.id || p.toUserId === d.id)
          return isInPath ? "#3B82F6" : "#9CA3AF"
        }
        return d.verified ? "#8B5CF6" : "#6B7280"
      })
      .style("stroke", "#FFFFFF")
      .style("stroke-width", 2)
      .style("opacity", d => {
        if (selectedPath) {
          const isInPath = d.id === selectedPath.startUserId || d.id === selectedPath.endUserId ||
            selectedPath.path.some(p => p.fromUserId === d.id || p.toUserId === d.id)
          return isInPath ? 1 : 0.4
        }
        return 1
      })

    // Add user labels
    nodes.append("text")
      .text(d => d.name.split(' ')[0]) // First name only
      .attr("text-anchor", "middle")
      .attr("dy", "0.35em")
      .style("font-family", "system-ui, sans-serif")
      .style("font-size", "12px")
      .style("font-weight", "600")
      .style("fill", "#FFFFFF")
      .style("pointer-events", "none")

    // Add verification badges
    nodes.filter(d => d.verified)
      .append("circle")
      .attr("cx", 15)
      .attr("cy", -15)
      .attr("r", 8)
      .style("fill", "#3B82F6")
      .style("stroke", "#FFFFFF")
      .style("stroke-width", 2)

    nodes.filter(d => d.verified)
      .append("text")
      .attr("x", 15)
      .attr("y", -15)
      .text("✓")
      .attr("text-anchor", "middle")
      .attr("dy", "0.35em")
      .style("font-size", "10px")
      .style("font-weight", "bold")
      .style("fill", "#FFFFFF")
      .style("pointer-events", "none")

    // Update positions on simulation tick
    simulation.on("tick", () => {
      links
        .attr("x1", (d: any) => d.source.x)
        .attr("y1", (d: any) => d.source.y)
        .attr("x2", (d: any) => d.target.x)
        .attr("y2", (d: any) => d.target.y)

      nodes.attr("transform", d => `translate(${d.x},${d.y})`)
    })

    function dragstarted(event: any) {
      if (!event.active) simulation.alphaTarget(0.3).restart()
      event.subject.fx = event.subject.x
      event.subject.fy = event.subject.y
    }

    function dragged(event: any) {
      event.subject.fx = event.x
      event.subject.fy = event.y
    }

    function dragended(event: any) {
      if (!event.active) simulation.alphaTarget(0)
      event.subject.fx = null
      event.subject.fy = null
    }

    return () => {
      simulation.stop()
    }
  }, [users, connections, selectedPath, width, height, onUserClick, onUserHover])

  return (
    <div className={`chain-visualization ${className}`}>
      <svg
        ref={svgRef}
        width={width}
        height={height}
        style={{
          border: '1px solid #E5E7EB',
          borderRadius: '12px',
          background: '#F9FAFB'
        }}
      />
      
      {/* Connection legend */}
      {!selectedPath && (
        <div className="mt-4 flex flex-wrap gap-4 text-sm">
          <div className="flex items-center gap-2">
            <div className="w-4 h-0.5 bg-blue-500"></div>
            <span>Friends</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-4 h-0.5 bg-green-500"></div>
            <span>Colleagues</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-4 h-0.5 bg-yellow-500"></div>
            <span>Acquaintances</span>
          </div>
        </div>
      )}

      {/* Chain path info */}
      {selectedPath && (
        <div className="mt-4 p-4 bg-white rounded-lg border">
          <h3 className="font-semibold text-lg mb-2">Connection Chain</h3>
          <div className="space-y-2">
            <p className="text-gray-600">
              <span className="font-medium">{selectedPath.totalDegrees}</span> degrees of separation
            </p>
            <div className="flex flex-wrap gap-2">
              {selectedPath.contexts.map((context, index) => (
                <span 
                  key={index}
                  className="px-2 py-1 bg-blue-100 text-blue-800 rounded-full text-xs"
                >
                  {context}
                </span>
              ))}
            </div>
            <div className="text-sm text-gray-500">
              Strongest connection: <span className="font-medium">{selectedPath.strongestConnection}/10</span>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

// Helper function to get connection color by type
function getConnectionColor(type: string): string {
  switch (type) {
    case 'friend': return '#3B82F6'
    case 'colleague': return '#10B981'
    case 'family': return '#EF4444'
    case 'acquaintance': return '#F59E0B'
    case 'community': return '#8B5CF6'
    case 'event': return '#EC4899'
    default: return '#6B7280'
  }
}