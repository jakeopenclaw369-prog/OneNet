'use client'

import { useState } from 'react'
import { User, Connection, ChainPath } from '@/types/chain'
import ChainVisualization from './ChainVisualization'

interface ChainInterfaceProps {
  currentUser: User
  users: User[]
  connections: Connection[]
  onFindChain: (startUserId: string, endUserId: string) => Promise<ChainPath | null>
}

export default function ChainInterface({ 
  currentUser, 
  users, 
  connections, 
  onFindChain 
}: ChainInterfaceProps) {
  const [selectedUser, setSelectedUser] = useState<User | null>(null)
  const [chainPath, setChainPath] = useState<ChainPath | null>(null)
  const [hoveredUser, setHoveredUser] = useState<User | null>(null)
  const [loading, setLoading] = useState(false)

  const handleUserClick = async (user: User) => {
    if (user.id === currentUser.id) {
      // Reset if clicking on self
      setSelectedUser(null)
      setChainPath(null)
      return
    }

    setSelectedUser(user)
    setLoading(true)
    
    try {
      const path = await onFindChain(currentUser.id, user.id)
      setChainPath(path)
    } catch (error) {
      console.error('Error finding chain:', error)
      setChainPath(null)
    }
    
    setLoading(false)
  }

  const getConnectionsForUser = (userId: string) => {
    return connections.filter(conn => 
      conn.fromUserId === userId || conn.toUserId === userId
    ).length
  }

  const getMutualConnections = (user1Id: string, user2Id: string) => {
    const user1Connections = new Set(
      connections
        .filter(conn => conn.fromUserId === user1Id)
        .map(conn => conn.toUserId)
    )
    
    const user2Connections = connections
      .filter(conn => conn.fromUserId === user2Id)
      .map(conn => conn.toUserId)
    
    return user2Connections.filter(userId => user1Connections.has(userId)).length
  }

  return (
    <div className="chain-interface">
      {/* Header */}
      <div className="mb-6">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">
          Chain Explorer
        </h1>
        <p className="text-gray-600">
          Discover how you're connected to people through your network
        </p>
      </div>

      {/* Current user info */}
      <div className="bg-white rounded-lg shadow-sm border p-4 mb-6">
        <div className="flex items-center space-x-4">
          <div className="relative">
            <div className="w-12 h-12 rounded-full bg-gradient-to-r from-blue-500 to-purple-600 flex items-center justify-center">
              <span className="text-white font-semibold text-lg">
                {currentUser.name.charAt(0)}
              </span>
            </div>
            {currentUser.verified && (
              <div className="absolute -top-1 -right-1 w-5 h-5 bg-blue-500 rounded-full flex items-center justify-center">
                <span className="text-white text-xs">✓</span>
              </div>
            )}
          </div>
          <div>
            <h2 className="font-semibold text-lg">{currentUser.name}</h2>
            <p className="text-gray-500">@{currentUser.username}</p>
            <p className="text-sm text-gray-600">{getConnectionsForUser(currentUser.id)} connections</p>
          </div>
        </div>
      </div>

      {/* Main visualization */}
      <div className="bg-white rounded-lg shadow-sm border p-6 mb-6">
        {loading && (
          <div className="flex items-center justify-center h-64">
            <div className="text-center">
              <div className="animate-spin w-8 h-8 border-4 border-blue-500 border-t-transparent rounded-full mx-auto mb-2"></div>
              <p className="text-gray-600">Finding connection chain...</p>
            </div>
          </div>
        )}
        
        {!loading && (
          <ChainVisualization
            users={users}
            connections={connections}
            selectedPath={chainPath || undefined}
            onUserClick={handleUserClick}
            onUserHover={setHoveredUser}
            width={800}
            height={500}
            className="w-full"
          />
        )}
      </div>

      {/* Selected user info */}
      {selectedUser && (
        <div className="bg-white rounded-lg shadow-sm border p-6 mb-6">
          <div className="flex items-start space-x-4">
            <div className="relative">
              <div className="w-16 h-16 rounded-full bg-gradient-to-r from-green-500 to-blue-600 flex items-center justify-center">
                <span className="text-white font-semibold text-xl">
                  {selectedUser.name.charAt(0)}
                </span>
              </div>
              {selectedUser.verified && (
                <div className="absolute -top-1 -right-1 w-6 h-6 bg-blue-500 rounded-full flex items-center justify-center">
                  <span className="text-white text-sm">✓</span>
                </div>
              )}
            </div>
            
            <div className="flex-1">
              <div className="flex items-center space-x-2 mb-2">
                <h3 className="text-xl font-semibold">{selectedUser.name}</h3>
                {chainPath && (
                  <span className="px-2 py-1 bg-blue-100 text-blue-800 rounded-full text-sm">
                    {chainPath.totalDegrees} degrees away
                  </span>
                )}
              </div>
              
              <p className="text-gray-500 mb-1">@{selectedUser.username}</p>
              {selectedUser.bio && (
                <p className="text-gray-700 mb-3">{selectedUser.bio}</p>
              )}
              
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <span className="font-medium">Connections:</span>{' '}
                  {getConnectionsForUser(selectedUser.id)}
                </div>
                <div>
                  <span className="font-medium">Mutual friends:</span>{' '}
                  {getMutualConnections(currentUser.id, selectedUser.id)}
                </div>
              </div>
            </div>
            
            <div className="flex flex-col space-y-2">
              <button className="px-4 py-2 bg-blue-500 hover:bg-blue-600 text-white rounded-lg transition-colors">
                Connect
              </button>
              <button className="px-4 py-2 border border-gray-300 hover:bg-gray-50 text-gray-700 rounded-lg transition-colors">
                Message
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Network stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white rounded-lg shadow-sm border p-4">
          <h4 className="font-semibold text-gray-900 mb-2">Network Size</h4>
          <p className="text-2xl font-bold text-blue-600">{users.length}</p>
          <p className="text-gray-500 text-sm">Total users</p>
        </div>
        
        <div className="bg-white rounded-lg shadow-sm border p-4">
          <h4 className="font-semibold text-gray-900 mb-2">Connections</h4>
          <p className="text-2xl font-bold text-green-600">{connections.length}</p>
          <p className="text-gray-500 text-sm">Total relationships</p>
        </div>
        
        <div className="bg-white rounded-lg shadow-sm border p-4">
          <h4 className="font-semibold text-gray-900 mb-2">Your Reach</h4>
          <p className="text-2xl font-bold text-purple-600">
            {getConnectionsForUser(currentUser.id)}
          </p>
          <p className="text-gray-500 text-sm">Direct connections</p>
        </div>
      </div>

      {/* Instructions */}
      <div className="mt-6 p-4 bg-blue-50 rounded-lg">
        <h4 className="font-semibold text-blue-900 mb-2">How to use Chain Explorer</h4>
        <ul className="text-blue-800 text-sm space-y-1">
          <li>• Click on any person to see how you're connected</li>
          <li>• Drag users to explore the network</li>
          <li>• Connection thickness shows relationship strength</li>
          <li>• Colors represent different relationship types</li>
        </ul>
      </div>
    </div>
  )
}